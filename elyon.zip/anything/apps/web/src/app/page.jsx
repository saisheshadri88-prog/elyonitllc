"use client";

import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Menu,
  X,
  ChevronDown,
  Phone,
  Mail,
  MapPin,
  ArrowRight,
  Users,
  Rocket,
  Target,
  Briefcase,
  CheckCircle2,
  Globe,
  Cpu,
  Database,
  Cloud,
  Layout,
  Settings,
  TrendingUp,
  UserPlus,
  ShieldCheck,
  Send,
} from "lucide-react";
import { useForm } from "react-hook-form";

// Section Content Data
const ABOUT_US_SUB = [
  { id: "overview", title: "Company Overview", icon: Globe },
  { id: "who-we-are", title: "Who We Are", icon: Users },
  { id: "what-we-do", title: "What We Do", icon: Rocket },
  { id: "our-clients", title: "Our Clients", icon: Target },
];

const SERVICES_LIST = [
  "Software Engineering",
  "Data Intelligence",
  "Cloud & Infrastructure",
  "Product & Design",
  "Enterprise Operations",
  "Staff Augmentation",
  "Contract-to-Hire",
  "Direct Placement",
  "Managed Solutions (SOW)",
];

const CAREER_LIST = [
  "Work with Purpose",
  "Grow with Us",
  "Career Development",
  "Life with ElyonIT",
];

const CLIENTS = [
  {
    name: "HEXAWARE",
    logo: "https://images.seeklogo.com/logo-png/31/1/hexaware-technologies-logo-png_seeklogo-310094.png",
  },
  {
    name: "INFOSIS",
    logo: "https://p.kindpng.com/picc/s/440-4405158_infosys-logo-png-transparent-png.png",
  },
  {
    name: "IBM",
    logo: "https://www.pngall.com/wp-content/uploads/13/IBM-Logo-PNG-Pic.png",
  },
];

export default function ElyonLandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
  } = useForm();
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const onSubmit = async (data) => {
    // Simulate form submission
    console.log("Form data:", data);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setSubmitSuccess(true);
    reset();
    setTimeout(() => setSubmitSuccess(false), 5000);
  };

  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
    setIsMenuOpen(false);
    setActiveDropdown(null);
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          {/* Logo */}
          <div
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          >
            <img
              src="https://dtvoeevhaseb5.cloudfront.net/user-uploads/5b136b1b-15a3-4038-b313-611acbb46990.jpg"
              alt="ELYON IT LLC Logo"
              className="h-12 w-auto object-contain"
            />
            <span className="text-2xl font-bold tracking-tight bg-gradient-to-r from-[#84cc16] via-[#0ea5e9] to-[#ef4444] bg-clip-text text-transparent">
              ELYON IT LLC
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {/* ABOUT US Dropdown */}
            <div
              className="relative group"
              onMouseEnter={() => setActiveDropdown("about")}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="flex items-center gap-1 px-4 py-2 text-sm font-semibold hover:text-[#0ea5e9] transition-colors">
                ABOUT US <ChevronDown className="w-4 h-4" />
              </button>
              <AnimatePresence>
                {activeDropdown === "about" && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full left-0 w-64 bg-white border border-slate-100 shadow-xl rounded-xl p-2"
                  >
                    {ABOUT_US_SUB.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => scrollToSection(item.id)}
                        className="flex items-center gap-3 w-full p-3 text-left text-sm hover:bg-slate-50 rounded-lg transition-colors group/item"
                      >
                        <item.icon className="w-4 h-4 text-[#0ea5e9] group-hover/item:scale-110 transition-transform" />
                        {item.title}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* SERVICES Dropdown */}
            <div
              className="relative group"
              onMouseEnter={() => setActiveDropdown("services")}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="flex items-center gap-1 px-4 py-2 text-sm font-semibold hover:text-[#84cc16] transition-colors">
                SERVICES <ChevronDown className="w-4 h-4" />
              </button>
              <AnimatePresence>
                {activeDropdown === "services" && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full left-0 w-72 bg-white border border-slate-100 shadow-xl rounded-xl p-2"
                  >
                    <div className="grid grid-cols-1 gap-1">
                      {SERVICES_LIST.map((service) => (
                        <button
                          key={service}
                          onClick={() => scrollToSection("services")}
                          className="w-full p-2.5 text-left text-xs font-medium hover:bg-slate-50 rounded-lg transition-colors text-slate-600 hover:text-[#84cc16]"
                        >
                          {service}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* CAREER Dropdown */}
            <div
              className="relative group"
              onMouseEnter={() => setActiveDropdown("career")}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="flex items-center gap-1 px-4 py-2 text-sm font-semibold hover:text-[#f59e0b] transition-colors">
                CAREER <ChevronDown className="w-4 h-4" />
              </button>
              <AnimatePresence>
                {activeDropdown === "career" && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full left-0 w-64 bg-white border border-slate-100 shadow-xl rounded-xl p-2"
                  >
                    {CAREER_LIST.map((career) => (
                      <button
                        key={career}
                        onClick={() => scrollToSection("career")}
                        className="w-full p-3 text-left text-sm hover:bg-slate-50 rounded-lg transition-colors"
                      >
                        {career}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* CONTACT Button */}
            <button
              onClick={() => scrollToSection("contact")}
              className="px-4 py-2 text-sm font-semibold hover:text-[#ef4444] transition-colors"
            >
              CONTACT
            </button>

            {/* CTA Button */}
            <div className="ml-4 pl-4 border-l border-slate-200">
              <a
                href="tel:307-340-9398"
                className="flex items-center gap-2 bg-[#0ea5e9] text-white px-5 py-2.5 rounded-full text-sm font-bold hover:bg-[#0284c7] transition-all hover:shadow-lg active:scale-95"
              >
                <Phone className="w-4 h-4" /> 307-340-9398
              </a>
            </div>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden bg-white border-t border-slate-100 overflow-hidden"
            >
              <div className="p-4 space-y-2">
                <div className="py-2 border-b border-slate-50">
                  <span className="text-xs font-bold text-slate-400 px-2 uppercase">
                    About Us
                  </span>
                  <div className="mt-2 space-y-1">
                    {ABOUT_US_SUB.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => scrollToSection(item.id)}
                        className="w-full text-left px-4 py-2 text-sm"
                      >
                        {item.title}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="py-2 border-b border-slate-50">
                  <span className="text-xs font-bold text-slate-400 px-2 uppercase">
                    Services
                  </span>
                  <div className="mt-2 grid grid-cols-1 gap-1">
                    {SERVICES_LIST.map((service) => (
                      <button
                        key={service}
                        onClick={() => scrollToSection("services")}
                        className="w-full text-left px-4 py-1.5 text-sm"
                      >
                        {service}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="py-2 border-b border-slate-50">
                  <span className="text-xs font-bold text-slate-400 px-2 uppercase">
                    Career
                  </span>
                  <div className="mt-2 space-y-1">
                    {CAREER_LIST.map((career) => (
                      <button
                        key={career}
                        onClick={() => scrollToSection("career")}
                        className="w-full text-left px-4 py-2 text-sm"
                      >
                        {career}
                      </button>
                    ))}
                  </div>
                </div>
                <button
                  onClick={() => scrollToSection("contact")}
                  className="w-full text-left px-2 py-3 text-sm font-bold"
                >
                  CONTACT
                </button>
                <a
                  href="tel:307-340-9398"
                  className="flex items-center justify-center gap-2 bg-[#0ea5e9] text-white p-4 rounded-xl font-bold"
                >
                  <Phone size={18} /> Call Us: 307-340-9398
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="pt-20">
        {/* Hero Section */}
        <section className="relative py-20 lg:py-32 overflow-hidden bg-slate-50">
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#84cc16] rounded-full blur-[120px] -mr-64 -mt-64" />
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-[#0ea5e9] rounded-full blur-[120px] -ml-64 -mb-64" />
          </div>

          <div className="max-w-7xl mx-auto px-4 relative">
            <div className="max-w-3xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0ea5e9]/10 text-[#0ea5e9] text-sm font-bold mb-6"
              >
                <Rocket size={16} /> Elyon IT Staffing & Consulting
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="text-5xl lg:text-7xl font-extrabold leading-tight tracking-tight mb-8"
              >
                The Future of <span className="text-[#84cc16]">Talent.</span>
                <br />
                The Power of <span className="text-[#0ea5e9]">Precision.</span>
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="text-xl text-slate-600 leading-relaxed mb-10"
              >
                Bridging the gap between visionary companies and the world’s
                most elite technical professionals. We don’t just fill roles; we
                build the architectural backbone of innovation.
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="flex flex-col sm:flex-row gap-4"
              >
                <button
                  onClick={() => scrollToSection("services")}
                  className="px-8 py-4 bg-[#0ea5e9] text-white rounded-xl font-bold text-lg hover:bg-[#0284c7] transition-all hover:shadow-xl hover:-translate-y-1"
                >
                  Explore Services
                </button>
                <button
                  onClick={() => scrollToSection("contact")}
                  className="px-8 py-4 bg-white border-2 border-slate-200 text-slate-900 rounded-xl font-bold text-lg hover:border-[#0ea5e9] hover:text-[#0ea5e9] transition-all"
                >
                  Contact Us
                </button>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Company Overview Section */}
        <section id="overview" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <h2 className="text-3xl font-bold mb-6 flex items-center gap-3 text-[#0ea5e9]">
                  <Globe className="w-8 h-8" /> Company Overview
                </h2>
                <div className="space-y-6 text-lg text-slate-600 leading-relaxed">
                  <p>
                    At Elyon IT LLC, we believe that in a rapidly evolving
                    digital landscape, the right talent isn't just a
                    resource—it’s a competitive advantage.
                  </p>
                  <p>
                    Headquartered in Wyoming, USA, we are a premier IT staffing
                    and consultancy firm dedicated to bridging the gap between
                    visionary companies and the world’s most elite technical
                    professionals.
                  </p>
                  <p>
                    We empower enterprises and high-growth startups to scale
                    faster, smarter, and with absolute confidence by combining
                    high-velocity recruitment with a deep understanding of
                    emerging technologies.
                  </p>
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="relative"
              >
                <div className="aspect-square bg-slate-100 rounded-3xl overflow-hidden shadow-2xl relative group">
                  <img
                    src="https://dtvoeevhaseb5.cloudfront.net/user-uploads/5b136b1b-15a3-4038-b313-611acbb46990.jpg"
                    alt="Elyon IT Workspace"
                    className="w-full h-full object-cover grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0ea5e9]/80 to-transparent flex items-end p-8">
                    <p className="text-white text-2xl font-bold">
                      Innovation through Talent
                    </p>
                  </div>
                </div>
                {/* Stats floating card */}
                <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl border border-slate-100 hidden sm:block">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[#84cc16]/10 rounded-full flex items-center justify-center">
                      <Users className="text-[#84cc16]" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-slate-900">500+</p>
                      <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">
                        Professionals Placed
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Who We Are & What We Do */}
        <section className="py-24 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Who We Are */}
              <motion.div
                id="who-we-are"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-2 h-full bg-[#84cc16]" />
                <div className="w-16 h-16 bg-[#84cc16]/10 rounded-2xl flex items-center justify-center mb-8">
                  <Users className="w-8 h-8 text-[#84cc16]" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Who We Are</h3>
                <p className="text-slate-600 leading-relaxed text-lg">
                  A passionate team of IT industry veterans, recruiters, and
                  technologists united by a common goal — to make talent
                  acquisition seamless, effective, and future-ready for US
                  enterprises.
                </p>
              </motion.div>

              {/* What We Do */}
              <motion.div
                id="what-we-do"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-2 h-full bg-[#f59e0b]" />
                <div className="w-16 h-16 bg-[#f59e0b]/10 rounded-2xl flex items-center justify-center mb-8">
                  <Rocket className="w-8 h-8 text-[#f59e0b]" />
                </div>
                <h3 className="text-2xl font-bold mb-4">What We Do</h3>
                <p className="text-slate-600 leading-relaxed text-lg">
                  We specialize in IT staffing, recruitment, ERP
                  implementations, cloud solutions, and custom application
                  development — serving clients from startups to Fortune 500
                  enterprises.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Clients Section */}
        <section id="our-clients" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <h2 className="text-sm font-bold text-[#ef4444] uppercase tracking-widest mb-4">
              Trusted Partnerships
            </h2>
            <h3 className="text-4xl font-bold mb-16">Our Elite Clients</h3>
            <div className="flex flex-wrap justify-center items-center gap-12 lg:gap-24 grayscale opacity-60 hover:grayscale-0 transition-all">
              {CLIENTS.map((client) => (
                <motion.div
                  key={client.name}
                  whileHover={{ scale: 1.05 }}
                  className="flex flex-col items-center gap-4"
                >
                  <img
                    src={client.logo}
                    alt={client.name}
                    className="h-12 lg:h-16 w-auto object-contain"
                  />
                  <span className="text-xs font-bold text-slate-400">
                    {client.name}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section
          id="services"
          className="py-24 bg-slate-900 text-white relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#84cc16]/10 rounded-full blur-[120px] -mr-80 -mt-80" />

          <div className="max-w-7xl mx-auto px-4 relative">
            <div className="mb-16">
              <h2 className="text-3xl font-bold flex items-center gap-3 text-[#84cc16]">
                <Cpu className="w-8 h-8" /> Our Services
              </h2>
              <p className="text-slate-400 mt-4 text-lg max-w-2xl">
                Comprehensive IT solutions designed for scale and efficiency.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {SERVICES_LIST.map((service, index) => (
                <motion.div
                  key={service}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="group bg-white/5 border border-white/10 p-8 rounded-2xl hover:bg-white/10 hover:border-[#84cc16]/50 transition-all"
                >
                  <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#84cc16] group-hover:text-white transition-colors">
                    {index % 3 === 0 ? (
                      <Database size={24} />
                    ) : index % 3 === 1 ? (
                      <Cloud size={24} />
                    ) : (
                      <Layout size={24} />
                    )}
                  </div>
                  <h4 className="text-xl font-bold mb-3">{service}</h4>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    Custom-tailored approach to ensure your specific business
                    needs are met with high-caliber solutions.
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Career Section */}
        <section id="career" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="text-[#f59e0b] font-bold uppercase tracking-widest text-sm mb-4">
                Join The Team
              </h2>
              <h3 className="text-4xl font-bold">Shape The Future With Us</h3>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  title: "Work with Purpose",
                  icon: Target,
                  color: "text-[#0ea5e9]",
                  bg: "bg-[#0ea5e9]/10",
                },
                {
                  title: "Grow with Us",
                  icon: TrendingUp,
                  color: "text-[#84cc16]",
                  bg: "bg-[#84cc16]/10",
                },
                {
                  title: "Career Development",
                  icon: Briefcase,
                  color: "text-[#ef4444]",
                  bg: "bg-[#ef4444]/10",
                },
                {
                  title: "Life with ElyonIT",
                  icon: UserPlus,
                  color: "text-[#f59e0b]",
                  bg: "bg-[#f59e0b]/10",
                },
              ].map((item, idx) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-8 rounded-3xl border border-slate-100 hover:border-slate-300 transition-all text-center group"
                >
                  <div
                    className={`w-16 h-16 ${item.bg} rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform`}
                  >
                    <item.icon className={`w-8 h-8 ${item.color}`} />
                  </div>
                  <h4 className="text-lg font-bold mb-2">{item.title}</h4>
                  <p className="text-slate-500 text-sm">
                    Empowering your career path with elite opportunities.
                  </p>
                </motion.div>
              ))}
            </div>

            <div className="mt-16 bg-slate-900 rounded-[3rem] p-12 text-center text-white relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#f59e0b]/20 to-transparent pointer-events-none" />
              <h4 className="text-3xl font-bold mb-6 relative">
                Ready to take the next step?
              </h4>
              <button className="bg-white text-slate-900 px-10 py-4 rounded-full font-bold hover:bg-[#f59e0b] hover:text-white transition-all relative">
                View Current Openings
              </button>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-16">
              {/* Contact Info */}
              <div>
                <h2 className="text-4xl font-bold mb-8">Let's Connect</h2>
                <p className="text-slate-600 text-lg mb-12">
                  Partner with us to find the talent you need or the career
                  you've always wanted. Our experts are ready to assist you.
                </p>

                <div className="space-y-8">
                  <div className="flex items-start gap-6">
                    <div className="w-14 h-14 bg-white shadow-sm rounded-2xl flex items-center justify-center shrink-0">
                      <Phone className="text-[#0ea5e9]" />
                    </div>
                    <div>
                      <p className="text-slate-400 font-bold text-xs uppercase tracking-widest mb-1">
                        Call Us
                      </p>
                      <a
                        href="tel:307-340-9398"
                        className="text-xl font-bold hover:text-[#0ea5e9] transition-colors"
                      >
                        307-340-9398
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-6">
                    <div className="w-14 h-14 bg-white shadow-sm rounded-2xl flex items-center justify-center shrink-0">
                      <Mail className="text-[#84cc16]" />
                    </div>
                    <div>
                      <p className="text-slate-400 font-bold text-xs uppercase tracking-widest mb-1">
                        Email Us
                      </p>
                      <a
                        href="mailto:hr@elyonit.com"
                        className="text-xl font-bold hover:text-[#84cc16] transition-colors text-ellipsis overflow-hidden"
                      >
                        hr@elyonit.com
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-6">
                    <div className="w-14 h-14 bg-white shadow-sm rounded-2xl flex items-center justify-center shrink-0">
                      <MapPin className="text-[#ef4444]" />
                    </div>
                    <div>
                      <p className="text-slate-400 font-bold text-xs uppercase tracking-widest mb-1">
                        Visit Us
                      </p>
                      <p className="text-xl font-bold leading-snug">
                        1309 Coffeen Avenue STE 1200,
                        <br />
                        Sheridan, Wyoming 82801
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-12 flex items-center gap-6">
                  <span className="font-bold text-slate-400">FOLLOW US</span>
                  <div className="flex gap-4">
                    {["LinkedIn", "Twitter", "Facebook"].map((social) => (
                      <button
                        key={social}
                        className="w-10 h-10 bg-white shadow-sm rounded-full flex items-center justify-center hover:bg-slate-900 hover:text-white transition-all"
                      >
                        <ArrowRight size={16} />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Contact Form */}
              <div className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-100">
                <h3 className="text-2xl font-bold mb-8">Enter Your Details</h3>
                {submitSuccess ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="h-full flex flex-col items-center justify-center text-center p-12"
                  >
                    <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                      <CheckCircle2 size={40} />
                    </div>
                    <h4 className="text-2xl font-bold mb-2">Message Sent!</h4>
                    <p className="text-slate-500">
                      We'll get back to you shortly.
                    </p>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-slate-600 ml-1">
                          Full Name
                        </label>
                        <input
                          {...register("name", { required: true })}
                          placeholder="John Doe"
                          className={`w-full px-5 py-4 rounded-xl bg-slate-50 border ${errors.name ? "border-red-400" : "border-slate-100"} focus:bg-white focus:ring-2 focus:ring-[#0ea5e9] outline-none transition-all`}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-slate-600 ml-1">
                          Email Address
                        </label>
                        <input
                          {...register("email", {
                            required: true,
                            pattern: /^\S+@\S+$/i,
                          })}
                          placeholder="john@example.com"
                          className={`w-full px-5 py-4 rounded-xl bg-slate-50 border ${errors.email ? "border-red-400" : "border-slate-100"} focus:bg-white focus:ring-2 focus:ring-[#0ea5e9] outline-none transition-all`}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-600 ml-1">
                        Subject
                      </label>
                      <select
                        {...register("subject")}
                        className="w-full px-5 py-4 rounded-xl bg-slate-50 border border-slate-100 focus:bg-white focus:ring-2 focus:ring-[#0ea5e9] outline-none transition-all appearance-none"
                      >
                        <option>Staffing Inquiry</option>
                        <option>Service Request</option>
                        <option>Career Opportunity</option>
                        <option>General Message</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-600 ml-1">
                        Your Message
                      </label>
                      <textarea
                        {...register("message", { required: true })}
                        placeholder="Tell us about your needs..."
                        rows={4}
                        className={`w-full px-5 py-4 rounded-xl bg-slate-50 border ${errors.message ? "border-red-400" : "border-slate-100"} focus:bg-white focus:ring-2 focus:ring-[#0ea5e9] outline-none transition-all resize-none`}
                      />
                    </div>
                    <button
                      disabled={isSubmitting}
                      type="submit"
                      className="w-full bg-[#0ea5e9] text-white py-5 rounded-2xl font-bold text-lg hover:bg-[#0284c7] transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed group shadow-lg shadow-[#0ea5e9]/20"
                    >
                      {isSubmitting ? (
                        "Sending..."
                      ) : (
                        <>
                          Send Message{" "}
                          <Send
                            size={20}
                            className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform"
                          />
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-100 pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
            <div className="col-span-1 lg:col-span-1">
              <div className="flex items-center gap-3 mb-8">
                <img
                  src="https://dtvoeevhaseb5.cloudfront.net/user-uploads/5b136b1b-15a3-4038-b313-611acbb46990.jpg"
                  alt="ELYON IT LLC Logo"
                  className="h-10 w-auto"
                />
                <span className="text-xl font-bold">ELYON IT LLC</span>
              </div>
              <p className="text-slate-500 leading-relaxed">
                Elite IT staffing and consultancy firm dedicated to bridging the
                gap between visionary companies and technical professionals.
              </p>
            </div>

            <div>
              <h4 className="font-bold mb-8 uppercase tracking-widest text-xs text-slate-400">
                Quick Links
              </h4>
              <ul className="space-y-4 font-semibold text-slate-600">
                <li>
                  <button
                    onClick={() => scrollToSection("overview")}
                    className="hover:text-[#0ea5e9]"
                  >
                    About Us
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("services")}
                    className="hover:text-[#84cc16]"
                  >
                    Services
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("career")}
                    className="hover:text-[#f59e0b]"
                  >
                    Careers
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="hover:text-[#ef4444]"
                  >
                    Contact
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-8 uppercase tracking-widest text-xs text-slate-400">
                Services
              </h4>
              <ul className="space-y-4 text-slate-500 text-sm">
                <li>Software Engineering</li>
                <li>Data Intelligence</li>
                <li>Cloud & Infrastructure</li>
                <li>Managed Solutions (SOW)</li>
                <li>Staff Augmentation</li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-8 uppercase tracking-widest text-xs text-slate-400">
                Contact Details
              </h4>
              <ul className="space-y-4 text-slate-600">
                <li className="flex items-center gap-3">
                  <Phone size={16} className="text-[#0ea5e9]" /> 307-340-9398
                </li>
                <li className="flex items-center gap-3">
                  <Mail size={16} className="text-[#84cc16]" /> hr@elyonit.com
                </li>
                <li className="flex items-start gap-3">
                  <MapPin size={16} className="text-[#ef4444] mt-1" />
                  <span>
                    1309 Coffeen Avenue STE 1200,
                    <br />
                    Sheridan, WY 82801
                  </span>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-10 border-t border-slate-50 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-slate-400 text-sm">
              © 2026 Elyon IT LLC. All rights reserved.
            </p>
            <div className="flex gap-8 text-sm font-bold text-slate-400">
              <button className="hover:text-slate-900">Privacy Policy</button>
              <button className="hover:text-slate-900">Terms of Service</button>
            </div>
          </div>
        </div>
      </footer>

      {/* Animation Styles */}
      <style jsx global>
        {`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-fade-in {
            animation: fadeIn 0.5s ease-out forwards;
          }
        `}
      </style>
    </div>
  );
}
